About Addon:
It's built with the intent of having a non-obstructive UI which monitors the DOTs casted on a foe, by showing icons show ing which spells should be casted.


Installation:
Drag and drop the DOTMonitor folder onto the interface folder in the WOW installation folder.


Idea Behind It:
This add-on was built during my spare time, in an afternoon. It was originally developed for personal use for warlocks. Then I decided to adjust it for other classes.

Support:
I don't have all the classes to test with (Don't know how to use/play other classes), so please provide comments on curse so I'm able to reconfigure the add-on.

The add-on has been tested with the following:

Priest:
-Shadow

Warlock:
-Affliction
-Demonology
