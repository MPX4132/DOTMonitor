MPXFoundation = {
	Database		= _G["MPXFoundation_Database"]		or false,
	Terminal 		= _G["MPXFoundation_Terminal"] 		or false,
	Console 		= _G["MPXFoundation_Console"] 		or false,
	EventManager 	= _G["MPXFoundation_EventManager"] 	or false,
	Table			= _G["MPXFoundation_Table"]			or false,
}